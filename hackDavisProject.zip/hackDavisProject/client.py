import pygame

pygame.init()
width = 1820
height = 980
win = pygame.display.set_mode((width, height))
pygame.display.set_caption("Client")
background = pygame.image.load(r'grid_format_2.png')
playerIcon = pygame.image.load(r'char1 sprite.png')
dragonIcon = pygame.image.load(r'lizardman.png')
clientNumber =0

class Player:
    def __init__(self, x, y, width, height):
        self.inventory = 0
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.vel = 40

    def draw(self, win):
        win.blit(playerIcon, (self.x, self.y))

    def move(self):
        keys = pygame.key.get_pressed()

        if keys[pygame.K_LEFT]:
            if self.x <= -5:
                self.x = 1820
            else:
                self.x -= self.vel
        if keys[pygame.K_RIGHT]:
            if self.x >= 1825:
                self.x = 0
            else:
                self.x += self.vel
        if keys[pygame.K_UP]:
            if self.y <= -5:
                self.y = 980
            else:
                self.y -= self.vel
        if keys[pygame.K_DOWN]:
            if self.y >= 985:
                self.y = 0
            else:
                self.y += self.vel

        self.rect = (self.x, self.y, self.width, self.height)


class Dragon:
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.rect = (x, y, width, height)
        self.vel = 20

    def draw(self, win):
        win.blit(dragonIcon, (self.x, self.y))

    def move(self):
        keys = pygame.key.get_pressed()

        if keys[pygame.K_a]:
            if self.x <= -5:
                self.x -= 0
            else:
                self.x -= self.vel
        if keys[pygame.K_d]:
            if self.x >= 1800:
                self.x -= 0
            else:
                self.x += self.vel
        if keys[pygame.K_w]:
            if self.y <= -5:
                self.y -= 0
            else:
                self.y -= self.vel
        if keys[pygame.K_s]:
            if self.y >= 980:
                self.y -= 0
            else:
                self.y += self.vel

        self.rect = (self.x, self.y, self.width, self.height)

def redrawWindow(win, Player,Dragon):
    win.fill((255, 255, 255))
    win.blit(background, (0, 0))
    Dragon.draw(win)
    Player.draw(win)
    pygame.display.update()


def main():
    run = True
    p = Player(50, 50, 100, 100)
    p2 = Dragon(300, 300, 300, 300)
    while run:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
            p2.move()
            p.move()
            redrawWindow(win, p, p2)


main()
